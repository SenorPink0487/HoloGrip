import"./modulepreload-polyfill-B5Qt9EMX.js";const w="modulepreload",L=function(s){return"/"+s},g={},E=function(a,e,h){let c=Promise.resolve();if(e&&e.length>0){let t=function(o){return Promise.all(o.map(n=>Promise.resolve(n).then(l=>({status:"fulfilled",value:l}),l=>({status:"rejected",reason:l}))))};document.getElementsByTagName("link");const r=document.querySelector("meta[property=csp-nonce]"),p=(r==null?void 0:r.nonce)||(r==null?void 0:r.getAttribute("nonce"));c=t(e.map(o=>{if(o=L(o),o in g)return;g[o]=!0;const n=o.endsWith(".css"),l=n?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${o}"]${l}`))return;const d=document.createElement("link");if(d.rel=n?"stylesheet":w,n||(d.as="script"),d.crossOrigin="",d.href=o,p&&d.setAttribute("nonce",p),document.head.appendChild(d),n)return new Promise((m,y)=>{d.addEventListener("load",m),d.addEventListener("error",()=>y(new Error(`Unable to preload CSS for ${o}`)))})}))}function i(t){const r=new Event("vite:preloadError",{cancelable:!0});if(r.payload=t,window.dispatchEvent(r),!r.defaultPrevented)throw t}return c.then(t=>{for(const r of t||[])r.status==="rejected"&&i(r.reason);return a().catch(i)})};document.addEventListener("DOMContentLoaded",()=>{M(),T(),$(),P(),S()});function k(){return typeof window>"u"?!1:!!(window.__TAURI_INTERNALS__||window.__TAURI__||window.__TAURI_IPC__)}async function C(){if(k())try{const{invoke:s}=await E(async()=>{const{invoke:a}=await import("./core-DhEqZVGG.js");return{invoke:a}},[]);await s("open_simulation_window");return}catch(s){console.warn("open_simulation_window 失败，回退到 location 跳转:",s)}window.location.href="app.html"}function M(){const s=document.getElementById("cursor-glow"),a=document.getElementById("trail-container");if(!s||!a)return;let e=window.innerWidth/2,h=window.innerHeight/2,c=e,i=h;window.addEventListener("mousemove",l=>{e=l.clientX,h=l.clientY,n(l.clientX,l.clientY)});function t(){c+=(e-c)*.08,i+=(h-i)*.08,s.style.left=`${c}px`,s.style.top=`${i}px`,requestAnimationFrame(t)}t();let r=0,p=0;const o=8;function n(l,d){const m=l-r,y=d-p;if(Math.sqrt(m*m+y*y)<o)return;r=l,p=d;const v=document.createElement("div");v.className="trail-dot";const x=(Math.random()-.5)*8,b=(Math.random()-.5)*8;v.style.left=`${l+x}px`,v.style.top=`${d+b}px`;const f=Math.random()*6+4;v.style.width=`${f}px`,v.style.height=`${f}px`,a.appendChild(v),v.addEventListener("animationend",()=>v.remove())}}function T(){const s=document.getElementById("particle-canvas");if(!s)return;const a=s.getContext("2d"),e=[],h=55,c=125,i={x:null,y:null,radius:160};function t(){s.width=window.innerWidth,s.height=window.innerHeight}t(),window.addEventListener("resize",t),window.addEventListener("mousemove",n=>{i.x=n.clientX,i.y=n.clientY}),window.addEventListener("mouseleave",()=>{i.x=null,i.y=null});class r{constructor(){this.x=Math.random()*s.width,this.y=Math.random()*s.height,this.vx=(Math.random()-.5)*.35,this.vy=(Math.random()-.5)*.35,this.radius=Math.random()*1.5+1,this.baseAlpha=Math.random()*.2+.08,this.alpha=this.baseAlpha}update(){if(this.x+=this.vx,this.y+=this.vy,(this.x<0||this.x>s.width)&&(this.vx*=-1),(this.y<0||this.y>s.height)&&(this.vy*=-1),i.x!==null&&i.y!==null){const l=this.x-i.x,d=this.y-i.y,m=Math.sqrt(l*l+d*d);if(m<i.radius){const y=(i.radius-m)/i.radius;this.x+=l/m*y*1,this.y+=d/m*y*1,this.alpha=Math.min(this.baseAlpha+y*.35,.6)}else this.alpha>this.baseAlpha&&(this.alpha-=.01)}else this.alpha>this.baseAlpha&&(this.alpha-=.01)}draw(){a.beginPath(),a.arc(this.x,this.y,this.radius,0,Math.PI*2),a.fillStyle=`rgba(6, 182, 212, ${this.alpha})`,a.fill()}}for(let n=0;n<h;n++)e.push(new r);function p(){for(let n=0;n<e.length;n++)for(let l=n+1;l<e.length;l++){const d=e[n].x-e[l].x,m=e[n].y-e[l].y,y=Math.sqrt(d*d+m*m);if(y<c){const u=(1-y/c)*.08;a.beginPath(),a.moveTo(e[n].x,e[n].y),a.lineTo(e[l].x,e[l].y),a.strokeStyle=`rgba(139, 92, 246, ${u})`,a.lineWidth=.5,a.stroke()}}}function o(){a.clearRect(0,0,s.width,s.height),e.forEach(n=>{n.update(),n.draw()}),p(),requestAnimationFrame(o)}o()}function $(){const s=document.querySelectorAll(".nav-btn"),a=document.querySelectorAll(".tab-content");s.forEach(e=>{e.addEventListener("click",()=>{const h=e.getAttribute("data-target");s.forEach(i=>i.classList.remove("active")),e.classList.add("active"),a.forEach(i=>{i.classList.contains("active")&&(i.classList.remove("active"),setTimeout(()=>{i.style.display="none"},400))});const c=document.getElementById(h);c&&(c.style.display="block",setTimeout(()=>{c.classList.add("active")},50))})}),a.forEach(e=>{e.classList.contains("active")||(e.style.display="none")})}const A={math:{title:"01 / HoloMath 空间三维几何画板",tag:"MATHEMATICS // V0.1.1-ONLINE",desc:"HoloMath 是 HoloGrip 系列的核心几何渲染 system，目前已完成 V0.1.1 版本的开发上线。它通过在端侧捕获摄像头的手部姿态关键点，将屏幕映射向量转换成 3D 画布内的三维顶点。支持空中捏合画线、三维圆柱/棱锥生成，并可在空间坐标系内实时完成测量与交点运算，打破纸质平面几何的教学局限。",specs:{engine:"Vite + React + Three.js (R3F)",perf:"60 FPS Render // < 3ms Hand Latency",algorithm:"Analytical Spatial Geometry Core",version:"v0.1.1-stable"},demoColor:"var(--accent-cyan)",visualClass:"math-modal-demo",canLaunch:!0,demoHtml:`
            <div class="scene-3d" style="transform: scale(1.25) translateY(-5px); margin-top: 10px;">
                <div class="grid-floor-3d" style="bottom: 0px; transform: rotateX(75deg) translateZ(-25px); width: 180px; height: 180px;"></div>
                <div class="crystal-polyhedron" style="width: 48px; height: 48px;">
                    <div class="face f-front" style="width: 48px; height: 48px; transform: rotateY(0deg) translateZ(24px);"></div>
                    <div class="face f-back" style="width: 48px; height: 48px; transform: rotateY(180deg) translateZ(24px);"></div>
                    <div class="face f-left" style="width: 48px; height: 48px; transform: rotateY(-90deg) translateZ(24px);"></div>
                    <div class="face f-right" style="width: 48px; height: 48px; transform: rotateY(90deg) translateZ(24px);"></div>
                    <div class="face f-top" style="width: 48px; height: 48px; transform: rotateX(90deg) translateZ(24px);"></div>
                    <div class="face f-bottom" style="width: 48px; height: 48px; transform: rotateX(-90deg) translateZ(24px);"></div>
                </div>
                <svg class="math-measure-lines" style="position:absolute; width:100%; height:100%; top:0; left:0; pointer-events:none; z-index: 5;">
                    <line x1="50%" y1="15%" x2="50%" y2="85%" stroke="rgba(6, 182, 212, 0.25)" stroke-width="1" stroke-dasharray="3 3" />
                    <line x1="15%" y1="50%" x2="85%" y2="50%" stroke="rgba(6, 182, 212, 0.25)" stroke-width="1" stroke-dasharray="3 3" />
                    <line x1="28%" y1="28%" x2="72%" y2="72%" stroke="rgba(6, 182, 212, 0.5)" stroke-width="1.2" />
                    <circle cx="28%" cy="28%" r="3" fill="var(--accent-cyan)" />
                    <circle cx="72%" cy="72%" r="3" fill="var(--accent-cyan)" />
                    <text x="32%" y="25%" fill="var(--accent-cyan)" style="font-size: 8px; font-family: monospace;">A(12, 8, 35)</text>
                    <text x="56%" y="80%" fill="var(--accent-cyan)" style="font-size: 8px; font-family: monospace;">B(-4, -15, 20)</text>
                </svg>
            </div>
        `},physics:{title:"02 / HoloPhysics 空间物理沙盒",tag:"PHYSICS // DEVELOPMENT STAGE",desc:"HoloPhysics 是用于空间交互力学教学的物理仿真程序，目前正处于开发与测试阶段。该系统通过空气手势作为力场施加器，允许用户实时构建万有引力模型或电磁场。它能实时模拟出行星围绕恒星运行的开普勒椭圆轨道，或者在多刚体发生碰撞时进行高精度的动量守恒定理数值计算。",specs:{engine:"R3F Physics / Canvas Sandbox",perf:"Collision Solve: < 1.5ms per step",algorithm:"Newtonian Rigid Body Dynamics",version:"v0.0.5-beta (Under Dev)"},demoColor:"var(--accent-emerald)",visualClass:"physics-modal-demo",canLaunch:!1,demoHtml:`
            <div class="physics-sandbox-simulation physics-visual-demo" style="transform: scale(1.1); width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; position: relative;">
                <div class="gravity-well" style="width: 14px; height: 14px; background: var(--accent-emerald); border-radius: 50%; box-shadow: 0 0 15px var(--accent-emerald), 0 0 25px var(--accent-emerald); z-index: 5;"></div>
                <div class="gravity-ring" style="position: absolute; width: 100px; height: 100px; border: 1px dashed rgba(16, 185, 129, 0.15); border-radius: 50%;"></div>
                <div class="gravity-ring" style="position: absolute; width: 160px; height: 160px; border: 1px dashed rgba(16, 185, 129, 0.08); border-radius: 50%;"></div>
                <div class="orbiting-planet planet-1" style="position: absolute; border-radius: 50%; width: 8px; height: 8px; animation: orbitPhysics1 5s infinite linear; background: var(--accent-emerald); box-shadow: 0 0 8px var(--accent-emerald);"></div>
                <div class="orbiting-planet planet-2" style="position: absolute; border-radius: 50%; width: 6px; height: 6px; animation: orbitPhysics2 9s infinite linear; background: var(--accent-emerald); box-shadow: 0 0 8px var(--accent-emerald);"></div>
                <div class="planet-3"></div>
            </div>
        `},shadowplay:{title:"03 / HoloShadow 空间生成式皮影戏",tag:"SHADOW PLAY // TRADITIONAL ART",desc:"HoloShadow 是一项将国家级非物质文化遗产同计算机视觉相结合的前沿探索，目前处于开发测试阶段。系统利用 MediaPipe Hands 提取的双手 21 个骨骼点，动态拟合和控制皮影戏角色的肢体关节及行走步态。辅以 AI 着色渲染管线，实时演算光影透过牛皮材质的漫透射折光，在虚空中重现中华光影艺术的魅力。",specs:{engine:"MediaPipe Hands + WebGL shaders",perf:"Skeletal Joints Map: 21 points / hand",algorithm:"Realtime Translucent Scattering Shader",version:"v0.0.2-alpha (Under Dev)"},demoColor:"var(--accent-amber)",visualClass:"shadowplay-modal-demo",canLaunch:!1,demoHtml:`
            <div class="shadowplay-simulation" style="display: flex; width: 85%; height: 85%; align-items: center; justify-content: space-around; z-index: 4; margin-top: 10px;">
                <svg class="hand-mesh" width="90" height="90" viewBox="0 0 100 100" style="filter: drop-shadow(0 0 6px var(--accent-amber));">
                    <path d="M 50 90 L 45 70 L 42 55 L 40 40 M 45 70 L 30 55 L 20 45 L 12 38 M 45 70 L 52 50 L 55 38 L 56 26 M 45 70 L 68 56 L 78 48 L 86 42 M 50 90 L 70 80 L 82 72" fill="none" stroke="rgba(245, 158, 11, 0.5)" stroke-width="1.2" />
                    <circle cx="50" cy="90" r="2.5" fill="#fff" />
                    <circle cx="45" cy="70" r="2" fill="var(--accent-amber)" />
                    <circle cx="42" cy="55" r="2" fill="var(--accent-amber)" />
                    <circle cx="40" cy="40" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="30" cy="55" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="20" cy="45" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="12" cy="38" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="52" cy="50" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="55" cy="38" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="56" cy="26" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="68" cy="56" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="78" cy="48" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="86" cy="42" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="70" cy="80" r="1.5" fill="var(--accent-amber)" />
                    <circle cx="82" cy="72" r="1.5" fill="var(--accent-amber)" />
                </svg>
                <div class="shadowplay-backlight" style="width: 90px; height: 90px; border-radius: 50%; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
                    <div class="puppet-silhouette" style="width: 45px; height: 45px; transform-origin: bottom center; animation: swayPuppet 4s infinite ease-in-out alternate;">
                        <svg class="svg-puppet" viewBox="0 0 100 100" style="width: 100%; height: 100%; filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.95));">
                            <path d="M50 20 L40 40 L60 40 Z M50 40 L50 80 M30 50 L50 40 L70 50" stroke="#000" stroke-width="4" stroke-linecap="round" fill="rgba(0,0,0,0.85)"/>
                            <circle cx="50" cy="15" r="8" fill="rgba(0,0,0,0.85)" />
                        </svg>
                    </div>
                </div>
            </div>
        `}};function P(){const s=document.querySelectorAll(".project-card"),a=document.getElementById("project-modal"),e=document.getElementById("modal-close"),h=document.getElementById("modal-body-content");if(!a||!e||!h)return;s.forEach(t=>{t.addEventListener("click",()=>{const r=t.getAttribute("data-project"),p=A[r];p&&c(p)})}),e.addEventListener("click",i),a.addEventListener("click",t=>{t.target===a&&i()});function c(t){const r=t.canLaunch?"启动在线仿真":"即将上线",p=t.canLaunch?"":'disabled style="opacity:0.5;cursor:not-allowed;"';h.innerHTML=`
            <div class="modal-title-area">
                <span class="badge" style="color: ${t.demoColor}; background: rgba(255,255,255,0.02); border-color: ${t.demoColor}33">${t.tag}</span>
                <h2>${t.title}</h2>
            </div>
            <div class="modal-content-grid">
                <div class="modal-demo-box ${t.visualClass}">
                    <div class="sim-status-tag" style="color: ${t.demoColor}">
                        <span class="sim-status-dot" style="background-color: ${t.demoColor}; box-shadow: 0 0 8px ${t.demoColor}"></span>
                        SIMULATION ACTIVE // 实时仿真中
                    </div>
                    ${t.demoHtml}
                </div>
                <p class="modal-info-text">${t.desc}</p>

                <div class="modal-specs">
                    <div class="spec-item">
                        <span class="spec-label">核心引擎 / Core Engine</span>
                        <span class="spec-value">${t.specs.engine}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">运行效能 / Performance</span>
                        <span class="spec-value">${t.specs.perf}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">计算算法 / Algorithm</span>
                        <span class="spec-value">${t.specs.algorithm}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">系统版本 / Version</span>
                        <span class="spec-value" style="color: ${t.demoColor}">${t.specs.version}</span>
                    </div>
                </div>
            </div>
            <div class="modal-action-bar">
                <button class="btn-secondary" id="modal-cancel">关闭</button>
                <button class="btn-primary" id="modal-launch" ${p} style="background: ${t.demoColor}; border-color: ${t.demoColor}; color: #000;">${r}</button>
            </div>
        `,a.classList.add("active"),document.getElementById("modal-cancel").addEventListener("click",i);const o=document.getElementById("modal-launch");t.canLaunch&&o.addEventListener("click",async()=>{o.innerText="正在激活空间渲染管线...",o.style.opacity="0.7",o.style.pointerEvents="none";try{await C()}catch(n){console.error("启动仿真失败:",n),o.innerText="启动失败，请重试",o.style.background="#ef4444",o.style.borderColor="#ef4444",o.style.color="#fff",o.style.pointerEvents="",o.style.opacity="1"}})}function i(){a.classList.remove("active")}}function S(){const s=document.getElementById("holo-id-card"),a=s?s.querySelector(".card-glare"):null,e=document.getElementById("copy-btn");if(!s||!a)return;let h=s.getBoundingClientRect();window.addEventListener("resize",()=>{h=s.getBoundingClientRect()}),s.addEventListener("mousemove",c=>{const i=c.clientX-h.left,t=c.clientY-h.top,r=i/h.width-.5,p=t/h.height-.5,o=-p*24,n=r*24;s.style.transform=`perspective(1000px) rotateX(${o}deg) rotateY(${n}deg) scale(1.02)`,a.style.setProperty("--glare-x",`${(r+.5)*100}%`),a.style.setProperty("--glare-y",`${(p+.5)*100}%`),a.style.opacity="1"}),s.addEventListener("mouseleave",()=>{s.style.transform="perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)",a.style.opacity="0",s.style.transition="transform 0.5s ease",setTimeout(()=>{s.style.transition="none"},500)}),e&&e.addEventListener("click",()=>{navigator.clipboard.writeText("senor0716@outlook.com").then(()=>{const i=e.innerHTML;e.innerHTML=`
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                        已复制邮箱
                    `,e.style.borderColor="#10b981",e.style.color="#10b981",setTimeout(()=>{e.innerHTML=i,e.style.borderColor="",e.style.color=""},2e3)}).catch(i=>{console.error("Clipboard copy failed: ",i)})})}
